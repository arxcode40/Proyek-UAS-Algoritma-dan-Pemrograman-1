#include <iostream>
using namespace std;
int main(){
	string wa, pilihan;
	float berat;
	int bayar;
	
	cout<<"=======FORMULIR PENDAFTARAN======="<<endl;
	cout<<"1. Metode CK (Cuci Kering)"<<endl;
	cout<<"2. Metode CKS (Cuci Kering Setrika)"<<endl;
	cout<<"!NOTE CKS Mempunyai Limit Berat 3-5Kg"<<endl;
	cout<<"\nPilih Metode (CK/CKS) : ";
	cin>>pilihan;
	cout<<"Masukkan Berat (Kg) : ";
	cin>>berat;
	cout<<"Masukkan NO WA : ";
	cin>>wa;
	
	cout<<"\n===Metode Pembayaran==="<<endl;
	cout<<"1. Bayar Sekarang"<<endl;
	cout<<"2. Bayar Nanti"<<endl;
	cout<<"Pilih (1/2) : ";
	cin>>bayar;
	
	if (bayar==1){
		cout<<"\nAnda Memilih Bayar Sekarang"<<endl;
		cout<<"Lanjut ke Program Pembayaran"<<endl;
	}else if (bayar==2){
		cout<<"\nAnda Memilih Bayar Nanti"<<endl;
		cout<<"Silahkan bayar saat laundry selesai"<<endl;
	}else{
		cout<<"Pilihan Tidak Valid"<<endl;
	}
	cout<<"==================================="<<endl;
}

