#include <iostream>
using namespace std;
int main(){
	float berat;
	int putih, sensitif, outlet;
	
	cout<<"======PENGELOLAAN LAPANGAN======\n";
	cout<<"\nProses Memasukan Pakaian ke Keranjang\n";
	
	cout<<"\nMasukkan Berat Pakaian (Kg) : ";
	cin>>berat;
	
	if (berat<=5){
		cout<<"Berat Pakaian : "<<berat<<"Kg\n";
		cout<<"Masukkan ke 1 Mesin Cuci\n";
	}else{
		float sisa=berat-5;
		
		cout<<"Berat Pakaian : "<<berat<<"Kg\n";
		cout<<"Pisahkan Pakaian :\n";
		cout<<"- Mesin 1 : 5Kg\n";
		cout<<"- Mesin 2 : "<<sisa<<"Kg\n";
	}
	
	cout<<"\nApakah Pakaian Ada Yg Berwarna Putih?\n(1 : ya, 2: tidak) : ";
	cin>>putih;
	
	if (putih==1){
		cout<<"Pakaian Putih Dipisahkan\n";
	}else{
		cout<<"Pakaian Berwarna Dipisahkan\n ";
	}
	
	cout<<"\nApakah ada Pakaian sensitif dan kotor?\n(1 : ya, 2: tidak) : ";
	cin>>sensitif;
	
	if (sensitif==1){
		cout<<"Proses Perendaman dan Penyikatan Halus\n\nLanjut ke";
	}else{
		cout<<"\nTidak Perlu Perendaman dan Penyikatan, Lanjut Proses\n";
	}
	
	cout<<"\nProses Pencucian Pakaian\n";
	cout<<"Proses Pengeringan Pakaian\n";
	
	cout<<"\n===PILIH OUTLET===\n";
	cout<<"1. Outlet A&B "<<endl;
	cout<<"2. Outlet C&D (Pick Up)"<<endl;
	cout<<"Pilih Outlet : ";
	cin>>outlet;
	
	if (outlet==1){
		cout<<"\nAnda Memimlih Outlet A&B\n";
		cout<<"Pakaian Anda Segera Diantar";
	}else if (outlet==2){
		cout<<"\nAnda Memilih Outlet C&B\n";
		cout<<"Pakaian Anda Disimpan Di Loker";
	}else{
		cout<<"Pilihan Tidak  Valid"<<endl;
	}
}


















