#include <iostream>
using namespace std;
int main (){
	string nama, metodecatat, metodepembayaran;
	int pilihan, catatharian, pilihancatat;
	int pemasukan, pengeluaran;
	
	cout<<"Masukkan Nama Anda: ";
	cin>>nama;
	
 	cout<<"\nMetode Pembayaran:\n";
    cout<<"1. Bayar di awal\n";
    cout<<"2. Bayar saat pengambilan\n";
    cout<<"Pilih : ";
    cin>>pilihan;

    if (pilihan == 1) {
        metodepembayaran= "Bayar di awal";
    } else {
        metodepembayaran= "Bayar saat pengambilan";
    }
	cout << "\nApakah pembayaran dicatat harian? \n(1 = Ya, 2 = Tidak) : ";
	cin >> catatharian;
	
	cout << "\nPilih metode pencatatan:\n";
    cout << "1. Manual\n";
    cout << "2. Aplikasi\n";
    cout << "Pilih : ";
    cin >> pilihancatat;

    metodecatat = (pilihancatat == 1) ? "Manual" : "Aplikasi";
    
    cout << "\nMasukkan total pemasukan hari ini : ";
    cin >> pemasukan;

    cout << "Masukkan total pengeluaran (deterjen, listrik, dll.) : ";
    cin >> pengeluaran;
    
     cout << "\n===== Ringkasan Transaksi Harian =====\n";
    cout << "Nama Pelanggan      : " << nama << endl;
    cout << "Metode Pembayaran   : " << metodepembayaran << endl;
    cout << "Pencatatan          : " << metodecatat << endl;

    if (catatharian == 1)
        cout << "Transaksi dicatat   : Harian\n";
    else
        cout << "Transaksi dicatat   : Tidak Harian\n";

    cout << "Pemasukan           : Rp " << pemasukan << endl;
    cout << "Pengeluaran         : Rp " << pengeluaran << endl;
    cout << "Keuntungan Hari Ini : Rp " << pemasukan - pengeluaran << endl;

    cout << "\nData transaksi telah direkap.\n";

}
