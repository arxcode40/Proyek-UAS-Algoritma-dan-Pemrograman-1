# Sistem Aplikasi Penyewaan Kamar Kos Bu Yeyen

## Kelompok 2

-   **Arya Putra Sadewa (251011400109)**
-   Aisyah Alya Khumaira (251011400120)
-   Ani Geatri (251011400119)
-   Satrio Pambudi Sadewo (251011400133)
-   Singgih Adhitama Widagdo (251011402145)
-   Tiara Ajeng Rachmawati Andryana (251011400145)
