#include <ctime>
#include <iostream>
#include <string>
using namespace std;

/**
 * ===============
 * Variabel Global
 * ===============
 */

string namaBulan[12] = {"Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"};
// Data Kamar
string nomorKamar[6] = {"101", "102", "103", "201", "202", "203"},
       statusKamar[6] = {"Tersedia", "Tersedia", "Tersedia", "Tersedia", "Tersedia", "Tersedia"},
       fasilitasKamar = "1 kasur dan 1 lemari kecil untuk 1 penghuni. 2 kasur dan 2 lemari untuk 2 penghuni. Kamar mandi dalam. Include biaya air.";
int hargaKamar[2] = {800000, 1000000};
// Data Penghuni
string nikPenghuni[6][2], namaPenghuni[6][2], kontakPenghuni[6][2];
// Riwayat Sewa
int jumlahPenghuni[6], jangkaWaktu[6], pembayaranLunas[6];
int tanggalMulai[6], bulanMulai[6], tahunMulai[6];
// Catatan Pengaduan
string catatanPengaduan[6];

/**
 * ================
 * Definisi Fungsi
 * ================
 */

// Manajemen Data Kamar
void menuDataKamar(),
    lihatDataKamar(),
    ubahDataKamar(),
    ubahFasilitasKamar(),
    ubahHargaKamar();
// Pemesanan Kamar
void menuPemesananKamar();
// Pembayaran Tagihan
void menuPembayaranTagihan();
// Manajemen Data Penghuni
void menuDataPenghuni(),
    lihatDataPenghuni(),
    ubahDataPenghuni();
// Riwayat Sewa
void menuRiwayatSewa(),
    lihatRiwayatSewa(),
    hapusRiwayatSewa();
// Catatan Pengaduan
void menuCatatanPengaduan(),
    lihatCatatanPengaduan(),
    ubahCatatanPengaduan();

/**
 * ==========
 * Menu Utama
 * ==========
 */

int main()
{
    int menu = -1;
    while (menu != 0)
    {
        cout << "\n============================================\n"
             << "Sistem Aplikasi Penyewaan Kamar Kos Bu Yeyen\n"
             << "============================================\n"
             << "1. Manajemen Data Kamar\n"
             << "2. Pemesanan Kamar\n"
             << "3. Pembayaran Tagihan\n"
             << "4. Manajemen Data Penghuni\n"
             << "5. Riwayat Sewa\n"
             << "6. Catatan Pengaduan\n"
             << "Pilih menu: ";
        cin >> menu;

        switch (menu)
        {
        case 1:
            menuDataKamar();
            break;

        case 2:
            menuPemesananKamar();
            break;

        case 3:
            menuPembayaranTagihan();
            break;

        case 4:
            menuDataPenghuni();
            break;

        case 5:
            menuRiwayatSewa();
            break;

        case 6:
            menuCatatanPengaduan();
            break;

        default:
            menu = 0;
            cout << "\nTerima kasih telah menggunakan program ini :)";
            break;
        }
    }
    return 0;
}

/**
 * ================
 * Deklarasi Fungsi
 * ================
 */

// Manajemen Data Kamar
void menuDataKamar()
{
    int menu = -1;
    while (menu != 0)
    {
        cout << "\n====================\n"
             << "Manajemen Data Kamar\n"
             << "====================\n"
             << "1. Lihat Data Kamar\n"
             << "2. Ubah Data Kamar\n"
             << "3. Ubah Fasilitas Kamar\n"
             << "4. Ubah Harga Kamar\n"
             << "Pilih menu: ";
        cin >> menu;

        switch (menu)
        {
        case 1:
            lihatDataKamar();
            break;

        case 2:
            ubahDataKamar();
            break;

        case 3:
            ubahFasilitasKamar();
            break;

        case 4:
            ubahHargaKamar();
            break;

        default:
            menu = 0;
            break;
        }
    }
}

void lihatDataKamar()
{
    cout << "\nDaftar Data Kamar\n"
         << "=================\n"
         << "# | Nomor | Status\n"
         << "------------------\n";
    int jumlahKamar = sizeof(nomorKamar) / sizeof(nomorKamar[0]);
    for (int i = 0; i < jumlahKamar; i++)
    {
        cout << (i + 1) << " | " << nomorKamar[i] << " | " << statusKamar[i] << endl;
    }

    cout << "\nFasilitas:\n"
         << fasilitasKamar << "\n\n";

    cout << "Harga:\n";
    int tipeHarga = sizeof(hargaKamar) / sizeof(hargaKamar[0]);
    for (int i = 0; i < tipeHarga; i++)
    {
        cout << (i + 1) << " penghuni: Rp " << hargaKamar[i] << endl;
    }
}

void ubahDataKamar()
{
    int pilihan;
    cout << "\nDaftar Data Kamar\n"
         << "=================\n"
         << "# | Nomor | Status\n"
         << "------------------\n";
    int jumlahKamar = sizeof(nomorKamar) / sizeof(nomorKamar[0]);
    for (int i = 0; i < jumlahKamar; i++)
    {
        cout << (i + 1) << " | " << nomorKamar[i] << " | " << statusKamar[i] << endl;
    }
    cout << "Pilih kamar: ";
    cin >> pilihan;

    if (pilihan > 0 && pilihan <= jumlahKamar)
    {
        cout << "\nUbah Data Kamar\n"
             << "===============\n";
        cout << "Masukkan nomor kamar: ";
        cin >> nomorKamar[pilihan - 1];
        cout << "Masukkan status kamar: ";
        cin >> statusKamar[pilihan - 1];

        cout << "\nData kamar berhasil diubah\n";
    }
    else
    {
        cout << "\nPilihan tidak valid!\n";
    }
}

void ubahFasilitasKamar()
{
    cout << "\nFasilitas Kamar\n"
         << "===============\n"
         << fasilitasKamar << "\n";

    cout << "\nUbah Fasilitas Kamar\n"
         << "====================\n"
         << "Masukkan fasilitas kamar: ";
    cin.ignore();
    getline(cin, fasilitasKamar);

    cout << "\nFasilitas kamar berhasil diubah\n";
}

void ubahHargaKamar()
{
    cout << "\nHarga Kamar\n"
         << "===========\n";
    int tipeHarga = sizeof(hargaKamar) / sizeof(hargaKamar[0]);
    for (int i = 0; i < tipeHarga; i++)
    {
        cout << (i + 1) << " penghuni: Rp " << hargaKamar[i] << endl;
    }

    cout << "\nUbah Harga Kamar\n"
         << "================\n";
    for (int i = 0; i < tipeHarga; i++)
    {
        cout << "Masukkan harga kamar (" << (i + 1) << " penghuni): Rp ";
        cin >> hargaKamar[i];
    }

    cout << "\nHarga kamar berhasil diubah\n";
}

// Pemesanan Makanan
void menuPemesananKamar()
{
    int pilihan;
    cout << "\nDaftar Data Kamar\n"
         << "=================\n"
         << "# | Nomor | Status\n"
         << "------------------\n";
    int jumlahKamar = sizeof(nomorKamar) / sizeof(nomorKamar[0]);
    for (int i = 0; i < jumlahKamar; i++)
    {
        cout << (i + 1) << " | " << nomorKamar[i] << " | " << statusKamar[i] << endl;
    }

    cout << "\n===============\n"
         << "Pemesanan Kamar\n"
         << "===============\n"
         << "Pilih kamar: ";
    cin >> pilihan;

    if ((pilihan > 0 && pilihan <= jumlahKamar) && statusKamar[pilihan - 1] == "Tersedia")
    {
        cout << "Masukkan jumlah penghuni (Maks 2 orang): ";
        cin >> jumlahPenghuni[pilihan - 1];
        cout << endl;
        for (int i = 0; i < jumlahPenghuni[pilihan - 1]; i++)
        {
            cout << "Data Penghuni Ke-" << (i + 1)
                 << "\n==================\n";
            cout << "Masukkan NIK: ";
            cin >> nikPenghuni[pilihan - 1][i];
            cout << "Masukkan nama: ";
            cin.ignore();
            getline(cin, namaPenghuni[pilihan - 1][i]);
            cout << "Masukkan kontak: ";
            cin >> kontakPenghuni[pilihan - 1][i];
            cout << endl;
        }

        cout << "Masukkan tanggal mulai (d M Y): ";
        cin >> tanggalMulai[pilihan - 1] >> bulanMulai[pilihan - 1] >> tahunMulai[pilihan - 1];
        cout << "Masukkan jangka waktu (bulan): ";
        cin >> jangkaWaktu[pilihan - 1];
        statusKamar[pilihan - 1] = "Terisi";

        cout << "\nPemesanan kamar " << nomorKamar[pilihan - 1] << " berhasil\n";
    }
    else
    {
        cout << "\nPilihan tidak valid!\n";
    }
}

// Pembayaran Tagihan
void menuPembayaranTagihan()
{
    int pilihan, tagihan;
    cout << "\nDaftar Data Kamar\n"
         << "=================\n"
         << "# | Nomor | Status\n"
         << "------------------\n";
    int jumlahKamar = sizeof(nomorKamar) / sizeof(nomorKamar[0]);
    for (int i = 0; i < jumlahKamar; i++)
    {
        cout << (i + 1) << " | " << nomorKamar[i] << " | " << statusKamar[i] << endl;
    }

    cout << "\n==================\n"
         << "Pembayaran Tagihan\n"
         << "==================\n";
    cout << "Pilih kamar: ";
    cin >> pilihan;

    if ((pilihan > 0 && pilihan <= jumlahKamar) && statusKamar[pilihan - 1] == "Terisi")
    {
        int sisaTagihan = jangkaWaktu[pilihan - 1] - pembayaranLunas[pilihan - 1];
        cout << "\nJumlah tagihan: " << jangkaWaktu[pilihan - 1] << " bulan\n"
             << "Tagihan lunas: " << pembayaranLunas[pilihan - 1] << " bulan\n"
             << "Sisa tagihan: " << sisaTagihan << " bulan\n"
             << "Masukkan tagihan yang ingin dibayarkan (bulan): ";
        cin >> tagihan;

        if (tagihan > 0 && tagihan <= sisaTagihan)
        {
            int hargaTagihan = hargaKamar[jumlahPenghuni[pilihan - 1] - 1], totalTagihan = tagihan * hargaTagihan;
            int uang;

            cout << "Total tagihan: Rp " << totalTagihan
                 << "\nMasukkan uang pembayaran: Rp ";
            cin >> uang;

            if (uang >= totalTagihan)
            {
                pembayaranLunas[pilihan - 1] += tagihan;
                int kembalian = uang - totalTagihan;
                cout << "\nPembayaran tagihan berhasil\n"
                     << "Kembalian: Rp " << kembalian << endl;
            }
            else
            {
                cout << "\nUang pembayaran tidak cukup!\n";
            }
        }
        else
        {
            cout << "\nTagihan tidak valid!\n";
        }
    }
    else
    {
        cout << "\nPilihan tidak valid!\n";
    }
}

// Manajemen Data Penghuni
void menuDataPenghuni()
{
    int menu = -1;
    while (menu != 0)
    {
        cout << "\n=======================\n"
             << "Manajemen Data Penghuni\n"
             << "=======================\n"
             << "1. Lihat Data Penghuni\n"
             << "2. Ubah Data Penghuni\n"
             << "Pilih menu: ";
        cin >> menu;

        switch (menu)
        {
        case 1:
            lihatDataPenghuni();
            break;

        case 2:
            ubahDataPenghuni();
            break;

        default:
            menu = 0;
            break;
        }
    }
}

void lihatDataPenghuni()
{
    cout << "\nDaftar Data Penghuni\n"
         << "====================\n"
         << "NIK | Nama | Kontak\n"
         << "-------------------\n";
    int jumlahKamar = sizeof(nomorKamar) / sizeof(nomorKamar[0]);
    for (int i = 0; i < jumlahKamar; i++)
    {
        cout << (i + 1) << ". Kamar " << nomorKamar[i] << ":\n";
        for (int j = 0; j < 2; j++)
        {
            cout << (nikPenghuni[i][j] != "" ? nikPenghuni[i][j] : "-") << " | " << (namaPenghuni[i][j] != "" ? namaPenghuni[i][j] : "-") << " | " << (kontakPenghuni[i][j] != "" ? kontakPenghuni[i][j] : "-") << endl;
        }
    }
}

void ubahDataPenghuni()
{
    int pilihan;
    cout << "\nDaftar Data Penghuni\n"
         << "====================\n"
         << "NIK | Nama | Kontak\n"
         << "-------------------\n";
    int jumlahKamar = sizeof(nomorKamar) / sizeof(nomorKamar[0]);
    for (int i = 0; i < jumlahKamar; i++)
    {
        cout << (i + 1) << ". Kamar " << nomorKamar[i] << ":\n";
        for (int j = 0; j < 2; j++)
        {
            cout << (nikPenghuni[i][j] != "" ? nikPenghuni[i][j] : "-") << " | " << (namaPenghuni[i][j] != "" ? namaPenghuni[i][j] : "-") << " | " << (kontakPenghuni[i][j] != "" ? kontakPenghuni[i][j] : "-") << endl;
        }
    }
    cout << "Pilih kamar: ";
    cin >> pilihan;

    if ((pilihan > 0 && pilihan <= jumlahKamar) && statusKamar[pilihan - 1] == "Terisi")
    {
        cout << endl;
        for (int i = 0; i < jumlahPenghuni[pilihan - 1]; i++)
        {
            cout << "Data Penghuni Ke-" << (i + 1) << "\n";
            cout << "==================\n";
            if (i == 0)
                cin.ignore();
            cout << "Masukkan NIK: ";
            getline(cin, nikPenghuni[pilihan - 1][i]);
            cout << "Masukkan nama: ";
            getline(cin, namaPenghuni[pilihan - 1][i]);
            cout << "Masukkan kontak: ";
            getline(cin, kontakPenghuni[pilihan - 1][i]);
            cout << endl;
        }

        cout << "\nData penghuni berhasil diubah\n";
    }
    else
    {
        cout << "\nPilihan tidak valid!\n";
    }
}

// Riwayat Sewa
void menuRiwayatSewa()
{
    int menu = -1;
    while (menu != 0)
    {
        cout << "\n=================\n"
             << "Menu Riwayat Sewa\n"
             << "=================\n"
             << "1. Lihat Riwayat Sewa\n"
             << "2. Hapus Riwayat Sewa\n"
             << "Pilih menu: ";
        cin >> menu;

        switch (menu)
        {
        case 1:
            lihatRiwayatSewa();
            break;

        case 2:
            hapusRiwayatSewa();
            break;

        default:
            menu = 0;
            break;
        }
    }
}

void lihatRiwayatSewa()
{
    int pilihan;
    cout << "\nDaftar Data Kamar\n"
         << "=================\n"
         << "# | Nomor | Status\n"
         << "------------------\n";
    int jumlahKamar = sizeof(nomorKamar) / sizeof(nomorKamar[0]);
    for (int i = 0; i < jumlahKamar; i++)
    {
        cout << (i + 1) << " | " << nomorKamar[i] << " | " << statusKamar[i] << endl;
    }
    cout << "Pilih kamar: ";
    cin >> pilihan;

    if (pilihan > 0 && pilihan <= jumlahKamar)
    {
        cout << "\nRiwayat Sewa Kamar " << nomorKamar[pilihan - 1]
             << "\n======================\n"
             << "Daftar Data Penghuni:\n"
             << "# | NIK | Nama | Kontak\n"
             << "-----------------------\n";
        for (int i = 0; i < jumlahPenghuni[pilihan - 1]; i++)
        {
            cout << (i + 1) << " | " << (nikPenghuni[pilihan - 1][i] != "" ? nikPenghuni[pilihan - 1][i] : "-") << " | " << (namaPenghuni[pilihan - 1][i] != "" ? namaPenghuni[pilihan - 1][i] : "-") << " | " << (kontakPenghuni[pilihan - 1][i] != "" ? kontakPenghuni[pilihan - 1][i] : "-") << endl;
        }

        tm waktu = {};
        waktu.tm_mday = tanggalMulai[pilihan - 1];
        waktu.tm_mon = bulanMulai[pilihan - 1] - 1;
        waktu.tm_year = tahunMulai[pilihan - 1] - 1900;
        waktu.tm_mon += jangkaWaktu[pilihan - 1];
        mktime(&waktu);
        cout << "\nTanggal Mulai: " << tanggalMulai[pilihan - 1] << " " << (namaBulan[bulanMulai[pilihan - 1] - 1] != "" ? namaBulan[bulanMulai[pilihan - 1] - 1] : "0") << " " << tahunMulai[pilihan - 1]
             << "\nTanggal Selesai: " << waktu.tm_mday << " " << (namaBulan[waktu.tm_mon] != "" ? namaBulan[waktu.tm_mon] : "0") << " " << (waktu.tm_year + 1900) << endl;

        int sisaTagihan = jangkaWaktu[pilihan - 1] - pembayaranLunas[pilihan - 1];
        cout << "\nJumlah tagihan: " << jangkaWaktu[pilihan - 1] << " bulan\n"
             << "Tagihan lunas: " << pembayaranLunas[pilihan - 1] << " bulan\n"
             << "Sisa tagihan: " << sisaTagihan << " bulan\n";
    }
    else
    {
        cout << "\nPilihan tidak valid!\n";
    }
}

void hapusRiwayatSewa()
{
    int pilihan;
    cout << "\nDaftar Data Kamar\n"
         << "=================\n"
         << "# | Nomor | Status\n"
         << "------------------\n";
    int jumlahKamar = sizeof(nomorKamar) / sizeof(nomorKamar[0]);
    for (int i = 0; i < jumlahKamar; i++)
    {
        cout << (i + 1) << " | " << nomorKamar[i] << " | " << statusKamar[i] << endl;
    }
    cout << "Pilih kamar untuk menghapus riwayat sewa: ";
    cin >> pilihan;

    if ((pilihan > 0 && pilihan <= jumlahKamar) && statusKamar[pilihan - 1] == "Terisi")
    {
        statusKamar[pilihan - 1] = "Tersedia";

        for (int i = 0; i < jumlahPenghuni[pilihan - 1]; i++)
        {
            nikPenghuni[pilihan - 1][i] = namaPenghuni[pilihan - 1][i] = kontakPenghuni[pilihan - 1][i] = "";
        }

        jumlahPenghuni[pilihan - 1] = tanggalMulai[pilihan - 1] = bulanMulai[pilihan - 1] = tahunMulai[pilihan - 1] = jangkaWaktu[pilihan - 1] = pembayaranLunas[pilihan - 1] = 0;

        cout << "\nRiwayat sewa berhasil dihapus\n";
    }
    else
    {
        cout << "\nPilihan tidak valid!\n";
    }
}

// Catatan Pengaduan
void menuCatatanPengaduan()
{
    int menu = -1;
    while (menu != 0)
    {
        cout << "\n======================\n"
             << "Menu Catatan Pengaduan\n"
             << "======================\n"
             << "1. Lihat Catatan Pengaduan\n"
             << "2. Ubah Catatan Pengaduan\n"
             << "Pilih menu: ";
        cin >> menu;

        switch (menu)
        {
        case 1:
            lihatCatatanPengaduan();
            break;

        case 2:
            ubahCatatanPengaduan();
            break;

        default:
            menu = 0;
            break;
        }
    }
}

void lihatCatatanPengaduan()
{
    int pilihan;
    cout << "\nDaftar Data Kamar\n"
         << "=================\n"
         << "# | Nomor | Status\n"
         << "------------------\n";
    int jumlahKamar = sizeof(nomorKamar) / sizeof(nomorKamar[0]);
    for (int i = 0; i < jumlahKamar; i++)
    {
        cout << (i + 1) << " | " << nomorKamar[i] << " | " << statusKamar[i] << endl;
    }
    cout << "Pilih kamar: ";
    cin >> pilihan;

    if (pilihan > 0 && pilihan <= jumlahKamar)
    {
        cout << "\nCatatan Pengaduan Kamar " << nomorKamar[pilihan - 1]
             << "\n===========================\n"
             << (catatanPengaduan[pilihan - 1] != "" ? catatanPengaduan[pilihan - 1] : "(Tidak ada)") << endl;
    }
    else
    {
        cout << "\nPilihan tidak valid!\n";
    }
}

void ubahCatatanPengaduan()
{
    int pilihan;
    cout << "\nDaftar Data Kamar\n"
         << "=================\n"
         << "# | Nomor | Status\n"
         << "------------------\n";
    int jumlahKamar = sizeof(nomorKamar) / sizeof(nomorKamar[0]);
    for (int i = 0; i < jumlahKamar; i++)
    {
        cout << (i + 1) << " | " << nomorKamar[i] << " | " << statusKamar[i] << endl;
    }
    cout << "Pilih kamar: ";
    cin >> pilihan;

    if (pilihan > 0 && pilihan <= jumlahKamar)
    {
        cout << "\nCatatan Pengaduan Kamar " << nomorKamar[pilihan - 1]
             << "\n===========================\n"
             << (catatanPengaduan[pilihan - 1] != "" ? catatanPengaduan[pilihan - 1] : "(Tidak ada)") << endl;

        cout << "\nUbah Catatan Pengaduan\n"
             << "======================\n"
             << "Masukkan catatan pengaduan: ";
        cin.ignore();
        getline(cin, catatanPengaduan[pilihan - 1]);

        cout << "\nCatatan pengaduan berhasil diubah\n";
    }
    else
    {
        cout << "\nPilihan tidak valid!\n";
    }
}